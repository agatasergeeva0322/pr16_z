﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace prackt16_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Country> countries = new List<Country>();
        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text.Replace(" ", ""), out int rez))
            {
                long n = long.Parse(textBox1.Text.Replace(" ", ""));
                var sortCountry = countries.Where(c => c.Population > n)
                                       .OrderBy(c => c.NameCountry.Length)
                                       .ToList();

                listBox2.Items.Clear();
                foreach (Country country in sortCountry)
                {
                    listBox2.Items.Add(country.NameCountry + " " + country.Population);
                }
            }
            else MessageBox.Show("Формат ввода был некорректным!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("jupiter.jpg");
            if (File.Exists("countries.txt"))
            {
                //Занесение в коллекцию данных из файла
                string[] lines = File.ReadAllLines("countries.txt");
                foreach (string line in lines)
                {
                    char digit = line.First(c => char.IsDigit(c));
                    string[] part = line.Split(digit);
                    string name = part[0];
                    string popul = digit + part[1];
                    long population = long.Parse(popul.Replace(" ", ""));
                    countries.Add(new Country(name, population));
                }

                //Сортировка стран по длине строки
                var sortCountries = countries.OrderBy(c => c.NameCountry.Length);

                //Вывод отсортированных стран
                listBox1.Items.Clear();
                foreach (Country country in sortCountries)
                {
                    listBox1.Items.Add(country.NameCountry + " " + country.Population);
                }
            }
            else MessageBox.Show("Файл с данными не найден!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

    }
}

